require("fs").writeFileSync("/tmp/MARK_F","URL_DEP_SCRIPT_RAN")
